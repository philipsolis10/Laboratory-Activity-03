# Laboratory Activity No. 03_De Vale

Laboratory-Activity-No.-03

Own HTML Template 
Step-By-Step Lab Activity Instructions 
To complete this Laboratory Activity, setup an HTML template similar to the one used in the lecture videos from scratch (don't just submit the existing resource file). Include the following items at a minimum:

a head section 
a body section 
text in the body section 
use of paragraph tag(s) and heading tag(s) 
at least one image embedded from an external web location (like Google Images)
